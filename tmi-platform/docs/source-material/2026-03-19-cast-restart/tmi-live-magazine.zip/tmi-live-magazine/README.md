# THE MUSICIAN'S INDEX — LIVE MAGAZINE SYSTEM
## BerntoutGlobal XXL | Complete Page Package

---

## HOW TO USE IN YOUR VS CODE REPO

### 1. Drop files into your Next.js project:

```
tmi-platform/apps/web/public/tmi-live-magazine/
  ├── css/
  │   └── tmi-design-system.css     ← Core design system (all tokens, animations, components)
  ├── js/
  │   └── tmi-engine.js             ← Full JS engine (draggable, live photo, video, polls, etc.)
  └── pages/
      ├── index.html                ← Main Hub (homepage with all page grid)
      ├── promotional-hub.html      ← Live Artist Cards (NFL live photo + video players)
      ├── billboard-board.html      ← Live Rankings + Charts + Fan Polls
      ├── artist-profile.html       ← Full Artist Hub (rotating bio, jacket sponsors, analytics)
      ├── game-night.html           ← Game Night Hub (Name That Tune, schedule, live chat)
      ├── admin-command.html        ← Global Admin HUD (map, bots, kill switches, stats)
      └── winner-hall.html          ← Winner's Hall (confetti, leaderboard, sponsor strip)
```

### 2. For React/Next.js components, convert each page's sections into `.tsx` components using the same CSS class names from `tmi-design-system.css`.

### 3. Wire `tmi-engine.js` into your layout by loading it in `_app.tsx` or as a Script tag.

---

## DESIGN SYSTEM — COLORS & TOKENS

All colors are CSS variables. Do not hardcode hex values.

| Token              | Value    | Use                          |
|--------------------|----------|------------------------------|
| `--neon-orange`    | #FF6B00  | Primary CTA, highlight text  |
| `--neon-cyan`      | #00D4FF  | HUD borders, links, headers  |
| `--neon-pink`      | #FF1493  | LIVE badges, alerts          |
| `--neon-gold`      | #FFB800  | Rankings, champions          |
| `--tmi-black`      | #070a14  | Page background              |
| `--tmi-card`       | #0f1428  | Card background              |
| `--tier-free`      | #00C8FF  | Free tier accent             |
| `--tier-bronze`    | #CD7F32  | Bronze tier accent           |
| `--tier-gold`      | #FFD700  | Gold tier accent             |
| `--tier-platinum`  | #E8E8E8  | Platinum tier accent         |
| `--tier-diamond`   | #B9F2FF  | Diamond tier accent + glow   |

---

## PAGES BUILT

### 1. `index.html` — MAIN HUB
**Type:** Hybrid  
**Layout:** Navigation + Hero + Sponsor Ticker + Feature Banner + 12-card hub grid + Footer  
**Features:**
- Animated hero with live member count
- Infinite-scroll sponsor ticker (Nike, Amazon, Netflix, etc.)
- Feature banner with Winner's Hall + Game Night callouts
- Hub grid cards for all 12 platform sections
- Each card has thumbnail, tag (LIVE/HYBRID/GAME/HUD), and animated arrow
- Full responsive nav with coin counter

---

### 2. `promotional-hub.html` — LIVE ARTIST CARDS
**Type:** Live  
**Layout:** Filter tabs + Sponsor ticker + Artist grid (2×2 + featured wide card)  
**Features:**
- **NFL-style Live Photo parallax** — mouse-follow 3D tilt on every artist card
- LIVE badge with animated pulse dot + viewer count
- Reaction bubbles that emit floating emoji on click
- Full video player with PiP sponsor window + lower-third overlay
- Sponsor popup billboard (opens Charro Ace's sponsor board)
- Filter tabs: All / Live Now / Hip-Hop / R&B / Electronic / Pop
- Offline card styling
- Tier badges per artist (Diamond, Gold, Platinum, Bronze)

---

### 3. `billboard-board.html` — LIVE RANKINGS
**Type:** Live  
**Layout:** Billboard scroll header + Sponsor ticker + Chart list + Sidebar  
**Features:**
- Scroll/parchment header with neon-lit title (matches PDF page 6)
- Animated ranking bars (fill on scroll via IntersectionObserver)
- Movement indicators (▲+2, ▼-2, NEW, —)
- Founding Artist badge on #1 position
- Founding Artists portrait strip (first 10)
- Interactive Fan Poll widget (vote → bars animate)
- Mini Sponsor Board in sidebar
- Live stat counters (420K votes, 247 artists)

---

### 4. `artist-profile.html` — ARTIST PROFILE HUB
**Type:** Hybrid (vertical scroll operational hub)  
**Layout:** Full-width hero + sticky tabs + 2-col body  
**Features:**
- **Rotating Bio Story Engine** — 5 story angles (Origin, Sound, Current Era, Fan Connection, Studio Habits), auto-rotates every 12s, manual dot nav, refresh button
- **NFL Live Photo parallax** on both hero avatar and sidebar portrait
- **Interview chip strip** (scrollable Q&A snippets from artist)
- Fan poll on profile
- **Jacket Sponsor Board** — artist silhouette with sponsor patches (Nike, Amazon, Netflix, Hulu, Trader Joe's) — each clickable
- Sponsor popup with full billboard
- Full video player with PiP sponsor + lower-third
- Video highlight grid (3-col)
- Analytics mini-bars (Profile visits, Article reads, Sponsor clicks, Fan votes)
- Profile completion XP bar
- Article link card → connects to magazine article page
- Profile tabs (Main Hub, Studio, Analytics, Fans, Sponsors, Settings)

---

### 5. `game-night.html` — GAME NIGHT HUB
**Type:** Live  
**Layout:** Marquee lights header + 2-col (main show + sidebar)  
**Features:**
- Animated marquee bulbs (match PDF style)
- **Live game show timer** (countdown from 18 seconds)
- Active show card (Name That Tune!) with answer poll choices
- Audience face grid (40 avatars, random live/queue states)
- 6 game tile cards (Name That Tune, Deal or Feud, 1v10000, Cover Art Zoom, Lyric Fill, DJ Mix-Off)
- LIVE pulsing border on active game
- Sponsor Mission bar
- Tonight's schedule sidebar
- **Live chat** — auto-generates fan messages every 3.5s, user can type
- Tonight's leaderboard with streak badges

---

### 6. `admin-command.html` — GLOBAL ADMIN HUD
**Type:** Static HUD  
**Layout:** 3-col grid dashboard  
**Features:**
- Scan-line CRT effect on all cards
- USA city map with glowing/pulsing map dots (NYC, LA, Chicago, Houston, Miami, Atlanta, Detroit, Dallas)
- Revenue widget with animated counter
- **Bot Activity bars** (Map Bots, Booking Bots, Guard Bots, Sponsor Bots, Analytics Bots)
- **Head Bot status circle** (pulsing ONLINE indicator)
- **Kill Switch toggles** — on/off for every major system (Signup, Artist Onboard, Fan Onboard, Charts, Voting, Sponsor Bots, Email)
- Map Status alert panel
- Launch Gates progress display
- 3 Admin action buttons (Run Diagnostics, Execute Patch, Override System) with loading animation
- Live stat updates every 4 seconds

---

### 7. `winner-hall.html` — WINNER'S HALL
**Type:** Live  
**Layout:** Animated hero + winner card + leaderboard grid + sponsor strip  
**Features:**
- **Confetti engine** — auto-launches on page load + click
- Marquee lights header
- Champion card (Charro Ace, 7-week streak, awards, sponsor row)
- Top Artists leaderboard
- Top Fans leaderboard
- Sponsor strip at bottom (Nike, Frito Lay, Delta, Chevrolet)
- "Sponsor Next Week's Show" CTA

---

## JS ENGINE CLASSES (`tmi-engine.js`)

| Class | What It Does |
|-------|-------------|
| `DraggableCards` | Full drag-and-drop for canvas cards |
| `LivePhotoEffect` | NFL-style 3D parallax on artist photos (mouse + gyroscope) |
| `TMIVideoPlayer` | Custom video player with play/pause/scrub/time |
| `ConfettiEngine` | Multi-color confetti burst with physics |
| `PollEngine` | Poll voting with animated bar reveals |
| `SponsorPopup` | Sponsor billboard modal |
| `GameShowTimer` | Countdown timer with expire state |
| `AudienceRoom` | Live audience face grid with flicker |
| `RankingBars` | Scroll-triggered animated bar fills |
| `StatCounter` | Animated number count-up |
| `PageHub` | Single-page multi-section navigation |
| `PrizeWheel` | Spinning prize wheel with easing |

---

## WHAT WAS ADDED (BEYOND WHAT WAS ASKED)

1. **Neon cursor** — orange glow follows mouse, turns cyan on click
2. **CSS scan-line effect** — CRT texture on all HUD pages
3. **Gyroscope support** — Live Photo works with device tilt on mobile
4. **Auto-rotating bio stories** — 5 story angles rotate every 12s without touching backend
5. **Interview chip strip** — horizontal scroll Q&A quotes from artist
6. **Jacket Sponsor Board** — artist silhouette with positioned sponsor patches (motocross/race-suit concept)
7. **PiP sponsor window** — floating animated sponsor tile on video player, non-obstructive
8. **Lower-third overlay** — broadcast-style artist name bar on video
9. **Audience face flicker** — random cells light up pink on interval to simulate live activity
10. **Live stat counters** — admin page auto-increments show count and queue every 4s
11. **Founding Artist portrait strip** — first 10 artists permanently showcased
12. **Sponsor ticker infinite scroll** — pauses on hover, lists all current sponsors
13. **Filter tabs on Promotional Hub** — genre/status filtering
14. **Page enter animation** — smooth fade-up when navigating
15. **Staggered card entrance** — cards bounce in with delays on page load
16. **Kill switch toggles** — functional on/off for every platform system in Admin HUD
17. **Live chat simulation** — game night chat auto-generates fan messages
18. **Confetti auto-launch** — Winner's Hall launches 70 pieces on load
19. **Bio refresh button** — clicking ↻ advances to next story angle
20. **Sponsor popup close** — multiple close methods (X button, outline button)

---

## NEXT STEPS FOR COPILOT

1. Convert each HTML page section into a React `.tsx` component
2. Wire the bio stories array to the `Article.content` JSON from your editorial service
3. Connect the sponsor board tiles to your `SponsorTile` Prisma model
4. Hook `PollEngine` to your poll API endpoints
5. Replace emoji placeholders with real `<Image>` tags from artist media
6. Add the `LivePhotoEffect` to your artist card components globally
7. Wire `StatCounter` elements to your analytics API

---

## GEMINI AUDIT CHECKLIST

When Gemini reviews, check:
- [ ] All pages use CSS variables, no hardcoded hex values
- [ ] Profile pages scroll vertically ✓
- [ ] Article pages navigate horizontally ✓
- [ ] Sponsor board exists on artist profile ✓
- [ ] PiP sponsor window on video player ✓
- [ ] Live photo parallax on artist cards ✓
- [ ] Tier accents only (no full page redesigns) ✓
- [ ] Same base visual family across all pages ✓
- [ ] No static pages — all have animation/motion ✓
- [ ] Video players functional ✓
- [ ] Kill switches in admin ✓
- [ ] Bio rotation engine wired ✓
- [ ] Interview snippet strips present ✓
- [ ] Founding artist badges visible ✓
- [ ] Confetti on Winner's Hall ✓
