/* ============================================================
   TMI LIVE MAGAZINE — JAVASCRIPT ENGINE
   BerntoutGlobal XXL | The Musician's Index
   All interactive behavior: draggable cards, live photo,
   video players, confetti, game show, sponsor rotation
   ============================================================ */

/* ══════════════════════════════════════════════════════════
   DRAGGABLE CANVAS CARDS
══════════════════════════════════════════════════════════ */
class DraggableCards {
  constructor(containerSelector) {
    this.container = document.querySelector(containerSelector);
    if (!this.container) return;
    this.cards = this.container.querySelectorAll('.draggable');
    this.activeCard = null;
    this.offset = { x: 0, y: 0 };
    this.init();
  }

  init() {
    this.cards.forEach(card => {
      card.addEventListener('mousedown', e => this.startDrag(e, card));
      card.addEventListener('touchstart', e => this.startDrag(e.touches[0], card), { passive: true });
    });
    document.addEventListener('mousemove', e => this.drag(e));
    document.addEventListener('touchmove', e => this.drag(e.touches[0]), { passive: true });
    document.addEventListener('mouseup', () => this.endDrag());
    document.addEventListener('touchend', () => this.endDrag());
  }

  startDrag(e, card) {
    this.activeCard = card;
    const rect = card.getBoundingClientRect();
    const containerRect = this.container.getBoundingClientRect();
    this.offset.x = e.clientX - rect.left;
    this.offset.y = e.clientY - rect.top;
    card.classList.add('dragging');
    card.style.position = 'absolute';
    card.style.zIndex = 1000;
  }

  drag(e) {
    if (!this.activeCard) return;
    const containerRect = this.container.getBoundingClientRect();
    let x = e.clientX - containerRect.left - this.offset.x;
    let y = e.clientY - containerRect.top - this.offset.y;
    // Constrain within container
    x = Math.max(0, Math.min(x, containerRect.width - this.activeCard.offsetWidth));
    y = Math.max(0, Math.min(y, containerRect.height - this.activeCard.offsetHeight));
    this.activeCard.style.left = x + 'px';
    this.activeCard.style.top  = y + 'px';
  }

  endDrag() {
    if (!this.activeCard) return;
    this.activeCard.classList.remove('dragging');
    this.activeCard = null;
  }
}

/* ══════════════════════════════════════════════════════════
   LIVE PHOTO — NFL-STYLE PARALLAX
   3-second look-around effect on artist profile photos
══════════════════════════════════════════════════════════ */
class LivePhotoEffect {
  constructor(selector) {
    this.cards = document.querySelectorAll(selector);
    this.cards.forEach(card => this.attachEffect(card));
  }

  attachEffect(wrap) {
    const inner = wrap.querySelector('.live-photo-card');
    if (!inner) return;

    // Mouse-based parallax
    wrap.addEventListener('mousemove', e => {
      const rect = wrap.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const dx = (e.clientX - cx) / (rect.width / 2);
      const dy = (e.clientY - cy) / (rect.height / 2);
      inner.style.transition = 'transform 0.1s ease-out';
      inner.style.transform = `rotateY(${dx * 14}deg) rotateX(${-dy * 10}deg) scale(1.02)`;
      inner.classList.remove('auto-look');
    });

    wrap.addEventListener('mouseleave', () => {
      inner.style.transition = 'transform 0.8s ease-out';
      inner.style.transform = 'rotateY(0) rotateX(0) scale(1)';
      // Resume auto-look after mouse leaves
      setTimeout(() => {
        inner.classList.add('auto-look');
        inner.style.transition = '';
        inner.style.transform = '';
      }, 900);
    });

    // Gyroscope on mobile
    if (window.DeviceOrientationEvent) {
      window.addEventListener('deviceorientation', e => {
        const tilt = e.gamma / 45; // -1 to 1
        const pitch = e.beta / 45;
        inner.style.transform = `rotateY(${tilt * 12}deg) rotateX(${-pitch * 8}deg)`;
      });
    }

    // Start auto-look
    inner.classList.add('auto-look');
  }
}

/* ══════════════════════════════════════════════════════════
   VIDEO PLAYER ENGINE
══════════════════════════════════════════════════════════ */
class TMIVideoPlayer {
  constructor(selector) {
    document.querySelectorAll(selector).forEach(player => this.init(player));
  }

  init(player) {
    const playBtn = player.querySelector('.vp-play-btn');
    const progress = player.querySelector('.vp-progress');
    const fill = player.querySelector('.vp-progress-fill');
    const timeEl = player.querySelector('.vp-time');
    let playing = false;
    let progress_pct = 35;
    let timer = null;

    if (playBtn) {
      playBtn.addEventListener('click', () => {
        playing = !playing;
        playBtn.textContent = playing ? '⏸' : '▶';
        if (playing) {
          timer = setInterval(() => {
            progress_pct = Math.min(100, progress_pct + 0.3);
            if (fill) fill.style.width = progress_pct + '%';
            const total = 240;
            const current = Math.floor(total * progress_pct / 100);
            if (timeEl) timeEl.textContent = `${formatTime(current)} / ${formatTime(total)}`;
            if (progress_pct >= 100) {
              clearInterval(timer);
              playing = false;
              playBtn.textContent = '▶';
              progress_pct = 0;
            }
          }, 100);
        } else {
          clearInterval(timer);
        }
      });
    }

    if (progress) {
      progress.addEventListener('click', e => {
        const rect = progress.getBoundingClientRect();
        progress_pct = ((e.clientX - rect.left) / rect.width) * 100;
        if (fill) fill.style.width = progress_pct + '%';
      });
    }
  }
}

function formatTime(secs) {
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

/* ══════════════════════════════════════════════════════════
   CONFETTI ENGINE (Winner's Hall)
══════════════════════════════════════════════════════════ */
class ConfettiEngine {
  constructor(container) {
    this.container = document.querySelector(container);
    if (!this.container) return;
    this.colors = ['#FF6B00','#FFB800','#00D4FF','#FF1493','#00FF88','#8B2FC9'];
    this.pieces = [];
    this.active = false;
  }

  launch(count = 80) {
    if (this.active) return;
    this.active = true;
    const wrap = document.createElement('div');
    wrap.className = 'confetti-wrap';
    this.container.appendChild(wrap);

    for (let i = 0; i < count; i++) {
      const piece = document.createElement('div');
      piece.className = 'confetti-piece';
      piece.style.cssText = `
        left: ${Math.random() * 100}%;
        top: -10px;
        background: ${this.colors[Math.floor(Math.random() * this.colors.length)]};
        width: ${4 + Math.random() * 8}px;
        height: ${4 + Math.random() * 8}px;
        border-radius: ${Math.random() > 0.5 ? '50%' : '2px'};
        animation-duration: ${2 + Math.random() * 3}s;
        animation-delay: ${Math.random() * 2}s;
        opacity: 0;
      `;
      wrap.appendChild(piece);
    }

    setTimeout(() => {
      wrap.remove();
      this.active = false;
    }, 5000);
  }
}

/* ══════════════════════════════════════════════════════════
   POLL / TRIVIA ENGINE
══════════════════════════════════════════════════════════ */
class PollEngine {
  constructor() {
    document.querySelectorAll('.poll-option').forEach(opt => {
      opt.addEventListener('click', () => this.vote(opt));
    });
  }

  vote(selected) {
    const poll = selected.closest('.poll-block');
    if (!poll || poll.dataset.voted) return;
    poll.dataset.voted = 'true';

    const options = poll.querySelectorAll('.poll-option');
    const total = options.length * 30 + Math.floor(Math.random() * 200);
    const votes = [];
    let remaining = 100;
    options.forEach((opt, i) => {
      const pct = (i === parseInt(selected.dataset.index))
        ? 35 + Math.floor(Math.random() * 30)
        : Math.floor(remaining / (options.length - i - 0.5));
      votes.push(pct);
      remaining -= pct;
    });

    options.forEach((opt, i) => {
      opt.classList.add('voted');
      if (opt === selected) opt.classList.add('winner');
      const bar = opt.querySelector('.poll-bar-fill');
      const pctEl = opt.querySelector('.poll-pct');
      const pct = Math.min(100, Math.max(5, votes[i]));
      if (bar) setTimeout(() => bar.style.width = pct + '%', 100);
      if (pctEl) setTimeout(() => pctEl.textContent = pct + '%', 100);
    });
  }
}

/* ══════════════════════════════════════════════════════════
   SPONSOR POPUP PANEL
══════════════════════════════════════════════════════════ */
class SponsorPopup {
  constructor() {
    document.querySelectorAll('[data-sponsor-popup]').forEach(btn => {
      btn.addEventListener('click', () => this.open(btn.dataset.sponsorPopup));
    });
    document.querySelectorAll('.sponsor-popup-close').forEach(btn => {
      btn.addEventListener('click', () => this.close());
    });
  }

  open(artistId) {
    const popup = document.getElementById('sponsor-popup');
    if (popup) {
      popup.classList.add('active');
      popup.style.animation = 'bounceIn 0.4s ease';
    }
  }

  close() {
    const popup = document.getElementById('sponsor-popup');
    if (popup) popup.classList.remove('active');
  }
}

/* ══════════════════════════════════════════════════════════
   GAME SHOW TIMER
══════════════════════════════════════════════════════════ */
class GameShowTimer {
  constructor(el, seconds) {
    this.el = document.querySelector(el);
    this.total = seconds;
    this.remaining = seconds;
    this.timer = null;
  }

  start() {
    this.timer = setInterval(() => {
      this.remaining--;
      if (this.el) this.el.textContent = String(this.remaining).padStart(2, '0');
      if (this.remaining <= 0) {
        clearInterval(this.timer);
        this.el && this.el.closest('.game-timer')?.classList.add('expired');
      }
    }, 1000);
  }

  reset() {
    clearInterval(this.timer);
    this.remaining = this.total;
    if (this.el) this.el.textContent = String(this.total).padStart(2, '0');
  }
}

/* ══════════════════════════════════════════════════════════
   AUDIENCE ROOM — LIVE COUNT
══════════════════════════════════════════════════════════ */
class AudienceRoom {
  constructor(containerSel, countEl) {
    this.container = document.querySelector(containerSel);
    this.countEl = document.querySelector(countEl);
    this.count = 213;
    if (this.container) this.startFlicker();
  }

  startFlicker() {
    setInterval(() => {
      const delta = Math.floor(Math.random() * 5) - 2;
      this.count = Math.max(180, this.count + delta);
      if (this.countEl) this.countEl.textContent = this.count;

      // Randomly light up faces
      const faces = this.container.querySelectorAll('.audience-face');
      faces.forEach(f => {
        if (Math.random() > 0.92) {
          f.style.borderColor = 'var(--neon-pink)';
          f.style.boxShadow = '0 0 12px rgba(255,20,147,0.4)';
          setTimeout(() => {
            f.style.borderColor = '';
            f.style.boxShadow = '';
          }, 600);
        }
      });
    }, 2000);
  }
}

/* ══════════════════════════════════════════════════════════
   RANKING BARS — ANIMATED FILL ON SCROLL
══════════════════════════════════════════════════════════ */
class RankingBars {
  constructor() {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.querySelectorAll('.rank-bar-fill[data-width]').forEach(bar => {
            setTimeout(() => {
              bar.style.width = bar.dataset.width;
            }, 200);
          });
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.3 });

    document.querySelectorAll('.rank-bar-container').forEach(c => {
      observer.observe(c);
      // Set initial width to 0
      c.querySelectorAll('.rank-bar-fill').forEach(bar => {
        const w = bar.style.width;
        bar.dataset.width = w;
        bar.style.width = '0%';
      });
    });
  }
}

/* ══════════════════════════════════════════════════════════
   LIVE STAT COUNTER (Admin HUD)
══════════════════════════════════════════════════════════ */
class StatCounter {
  constructor(el, start, end, duration = 2000) {
    this.el = document.querySelector(el);
    if (!this.el) return;
    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        this.countUp(start, end, duration);
        observer.disconnect();
      }
    });
    observer.observe(this.el);
  }

  countUp(start, end, duration) {
    const range = end - start;
    const step = range / (duration / 16);
    let current = start;
    const timer = setInterval(() => {
      current += step;
      if (current >= end) { current = end; clearInterval(timer); }
      this.el.textContent = Math.floor(current).toLocaleString();
    }, 16);
  }
}

/* ══════════════════════════════════════════════════════════
   PAGE HUB NAVIGATION (between pages)
══════════════════════════════════════════════════════════ */
class PageHub {
  constructor() {
    this.pages = document.querySelectorAll('[data-page]');
    this.links = document.querySelectorAll('[data-goto]');
    this.links.forEach(link => {
      link.addEventListener('click', e => {
        e.preventDefault();
        this.goto(link.dataset.goto);
      });
    });
  }

  goto(pageId) {
    this.pages.forEach(p => {
      p.style.display = (p.dataset.page === pageId) ? 'block' : 'none';
      if (p.dataset.page === pageId) {
        p.classList.add('page-enter');
        setTimeout(() => p.classList.remove('page-enter'), 500);
      }
    });
    this.links.forEach(l => {
      l.classList.toggle('active', l.dataset.goto === pageId);
    });
    window.scrollTo(0, 0);
  }
}

/* ══════════════════════════════════════════════════════════
   ARTIST CARD — SPLIT REVEAL ON HOVER
══════════════════════════════════════════════════════════ */
function initSplitReveals() {
  document.querySelectorAll('.split-reveal').forEach(el => {
    el.addEventListener('mouseenter', () => el.classList.add('revealed'));
    el.addEventListener('mouseleave', () => el.classList.remove('revealed'));
  });
}

/* ══════════════════════════════════════════════════════════
   ROTATING PRIZE WHEEL (Game show)
══════════════════════════════════════════════════════════ */
class PrizeWheel {
  constructor(el) {
    this.el = document.querySelector(el);
    if (!this.el) return;
    this.spinning = false;
  }

  spin() {
    if (this.spinning) return;
    this.spinning = true;
    const deg = 720 + Math.floor(Math.random() * 360);
    this.el.style.transition = 'transform 3s cubic-bezier(0.17,0.67,0.12,0.99)';
    this.el.style.transform = `rotate(${deg}deg)`;
    setTimeout(() => {
      this.spinning = false;
      this.el.dispatchEvent(new CustomEvent('spinComplete'));
    }, 3100);
  }
}

/* ══════════════════════════════════════════════════════════
   SCROLL TICKER — BILLBOARD
══════════════════════════════════════════════════════════ */
function initBillboardTicker() {
  const ticker = document.querySelector('.billboard-ticker');
  if (!ticker) return;
  let pos = 0;
  const items = ticker.querySelectorAll('.ticker-item');
  setInterval(() => {
    pos = (pos + 1) % items.length;
    items.forEach((item, i) => {
      item.classList.toggle('active', i === pos);
    });
  }, 3000);
}

/* ══════════════════════════════════════════════════════════
   NEON CURSOR
══════════════════════════════════════════════════════════ */
function initNeonCursor() {
  const cursor = document.createElement('div');
  cursor.style.cssText = `
    position: fixed; pointer-events: none; z-index: 99999;
    width: 20px; height: 20px; border-radius: 50%;
    background: radial-gradient(circle, rgba(255,107,0,0.4) 0%, transparent 70%);
    mix-blend-mode: screen;
    transition: transform 0.15s ease;
  `;
  document.body.appendChild(cursor);
  document.addEventListener('mousemove', e => {
    cursor.style.left = (e.clientX - 10) + 'px';
    cursor.style.top = (e.clientY - 10) + 'px';
  });
  document.addEventListener('mousedown', () => {
    cursor.style.transform = 'scale(2)';
    cursor.style.background = 'radial-gradient(circle, rgba(0,212,255,0.5) 0%, transparent 70%)';
  });
  document.addEventListener('mouseup', () => {
    cursor.style.transform = 'scale(1)';
    cursor.style.background = 'radial-gradient(circle, rgba(255,107,0,0.4) 0%, transparent 70%)';
  });
}

/* ══════════════════════════════════════════════════════════
   INIT ALL ON DOM READY
══════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  // Live photo parallax on all artist card wraps
  new LivePhotoEffect('.live-photo-wrap');

  // Video players
  new TMIVideoPlayer('.video-player-shell');

  // Poll interactivity
  new PollEngine();

  // Sponsor popup
  new SponsorPopup();

  // Animated rank bars on scroll
  new RankingBars();

  // Billboard ticker
  initBillboardTicker();

  // Split reveals
  initSplitReveals();

  // Page hub (if multi-page shell)
  const hub = document.querySelector('[data-page-hub]');
  if (hub) new PageHub();

  // Neon cursor
  initNeonCursor();

  // Confetti on winners
  const winnerBtn = document.querySelector('.trigger-confetti');
  if (winnerBtn) {
    const confetti = new ConfettiEngine('.winners-section');
    winnerBtn.addEventListener('click', () => confetti.launch());
    // Auto-launch on load
    setTimeout(() => confetti.launch(60), 800);
  }

  // Stat counters
  document.querySelectorAll('[data-count-to]').forEach(el => {
    new StatCounter(`#${el.id}`, 0, parseInt(el.dataset.countTo), 2200);
  });

  // Audience room live
  if (document.querySelector('.audience-grid')) {
    new AudienceRoom('.audience-grid', '.live-count');
  }

  // Draggable canvas
  if (document.querySelector('.tmi-canvas')) {
    new DraggableCards('.tmi-canvas');
  }

  // Game timers
  document.querySelectorAll('[data-game-timer]').forEach(el => {
    const timer = new GameShowTimer(`#${el.id}`, parseInt(el.dataset.gameTimer));
    timer.start();
  });

  // Prize wheels
  document.querySelectorAll('.spin-btn').forEach(btn => {
    const wheel = new PrizeWheel('.prize-wheel');
    btn.addEventListener('click', () => wheel.spin());
  });

  console.log('%c🎵 TMI LIVE MAGAZINE ENGINE ONLINE', 'color:#FF6B00;font-size:14px;font-weight:bold;');
  console.log('%cBerntoutGlobal XXL — The Musician\'s Index', 'color:#00D4FF;font-size:11px;');
});

/* Export for modules */
if (typeof module !== 'undefined') {
  module.exports = {
    DraggableCards, LivePhotoEffect, TMIVideoPlayer,
    ConfettiEngine, PollEngine, SponsorPopup,
    GameShowTimer, AudienceRoom, RankingBars,
    StatCounter, PageHub, PrizeWheel
  };
}
